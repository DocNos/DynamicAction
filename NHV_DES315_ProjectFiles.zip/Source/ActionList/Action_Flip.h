// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Action.h"
#include "Action_Flip.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class ACTIONLIST_API UAction_Flip : public UAction
{
	GENERATED_BODY()
private:

	

public:
	UPROPERTY(BlueprintReadWrite)
	FRotator currRotation_;
	UPROPERTY(BlueprintReadWrite)
	FRotator flippedRotation_;

	virtual void Execute() override;
	virtual bool Update(float) override;
	virtual EActionType GetType() override { return EActionType::Flip; }

	UFUNCTION(BlueprintCallable, Category="Flip Action")
	void UpdateCurrentRotation(FRotator rotation) { currRotation_ = rotation;}

	void Initialize(AActor* Target, float Duration)
	{
		affectedObject_ = Target;
		actionDuration_ = Duration;
		actionCurrTime_ = 0.0f;
		SetType(EActionType::Flip);
	}

	void Init() override;
	
};
